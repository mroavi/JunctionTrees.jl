The UAI and EVID file are directly downloaded from the UAI2014 competition; they describe the problem and the evidence (observations) respectively.

The GR file is generated based on just the preamble of the UAI file (by a small tool I made). It contains the dependencies between the random variables, but not the probability tables themselves. This is the input for the solver of Tamaki.

The TD file is the output of the solver. It contains the junction tree (i.e. factor graph with circular dependencies removed), but again not the probability tables themselves. Together with the UAI and EVID file, the TD file is the input for my code generator (GenGenGen in F#).

The MAR file is the reference solution. This should be equal to the values output by the Halide executable (i.e. filter.cpp).

For the UAI, EVID and MAR files, check the UAI 2014 competition for the specification: http://www.hlt.utdallas.edu/~vgogate/uai14-competition/index.html.
For the GR and TD files, check the PACE 2017 competition for the specification: https://pacechallenge.org/2017/treewidth/.